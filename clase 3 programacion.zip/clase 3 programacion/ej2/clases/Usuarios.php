
<?php

class Usuario
{
    public $nombre='';
    public $clave='';

    function Constructor($nombre, $clave)
    {
       $this->nombre=$nombre;
       $this->clave=$clave;
    }

    function ToString()
    {
        $myUsuario="$this->nombre"."  "."$this->clave";
        return $myUsuario;
    }

    public function ToJson($ruta, $usuario)
    {
        $contArchivo = file_get_contents($ruta);

        if(is_null($contArchivo))
        {
            $milista= array($usuario);

        }
        else
        {
            $milista = json_decode($contArchivo);
            array_push($milista, $usuario);
        }
        
        return json_encode($milista);
    }
}

