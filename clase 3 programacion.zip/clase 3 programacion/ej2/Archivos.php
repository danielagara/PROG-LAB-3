<?php
include ".\\clases\\Usuarios.php";

$nombre=$_POST['nombre'];
$clave=$_POST['clave'];
$usuario= new Usuario;


$usuario->Constructor($nombre, $clave);


echo $usuario->ToString();



if(file_exists (".\\Datos\\Datos.json"))
{
    $listaUsuarios=$usuario->ToJson(".\\Datos\\Datos.json", $usuario);
    $fichero=fopen ( ".\\Datos\\Datos.json" , "w+");
    fwrite($fichero, $listaUsuarios);
    fclose($fichero);
}
else
{
    mkdir(".\\Datos");
    $fichero=fopen ( ".\\Datos\\Datos.json" , "w+");
    fwrite($fichero, $usuario->ToJson(".\\Datos\\Datos.json", $usuario));
    fclose($fichero);
}


//echo $algo;