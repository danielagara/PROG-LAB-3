<?php

class Producto
{
    public $nombre='';
    public $codBarra='';

function Constructor($nombre, $codBarra)
{
    $this->nombre=$nombre;
    $this->codBarra=$codBarra;
}

function ToString()
{
    $myProducto="$this->nombre"."$this->codBarra";
    
    return $myProducto;
}


}

//que guarde la foto en la carpeta 