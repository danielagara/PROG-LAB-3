<?php
//nuevo obj producto con parametros de post
//to string con echo de los 2 productos
//guarda archivo, le cambia el nombre lo mueve a otra carpeta, si ya existe lo guarda en la carpet backup agregandole la fecha dle cambio
include ".\\clases\\Producto.php";

$nombre=$_POST['nombre'];
$codBarra=$_POST['codBarra'];
$producto= new Producto;
var_dump($_FILES['archivo']);
$producto->Constructor($nombre, $codBarra);
$date=getdate();
$target_dir = "Archivos/";
$backup_dir = "Backup/";

//$extension=$_FILES['archivo']['']


if(file_exists($target_dir.$producto->ToString().".jpg"))
{
    if(move_uploaded_file($_FILES["archivo"]["tmp_name"], $backup_dir.$producto->ToString().date('dmyhhmmss').".jpg"))
    {
        echo "The file ". basename( $_FILES["archivo"]["name"]). " has been uploaded.";
    }
}
else
{
    if(move_uploaded_file($_FILES["archivo"]["tmp_name"], $target_dir.$producto->ToString().".jpg"))
    {
        echo "The file ". basename( $_FILES["archivo"]["name"]). " has been uploaded.";
    }
}

if(file_exists (".\\Datos\\Datos.json"))
{
    $fichero=fopen ( ".\\Datos\\Datos.json" , "w+");
    fwrite($fichero, $producto->ToJson(".\\Datos\\Datos.json", $producto));
    fclose($fichero);
}
else
{
    mkdir(".\\Datos");
    $fichero=fopen ( ".\\Datos\\Datos.json" , "w+");
    fwrite($fichero, $producto->ToJson(".\\Datos\\Datos.json", $producto));
    fclose($fichero);
}


//$producto->Archivo($archivo, ".\\Archivos");

