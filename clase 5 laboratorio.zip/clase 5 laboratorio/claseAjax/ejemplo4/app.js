window.addEventListener('load', inicializarEventos, false);

function inicializarEventos()
{
    document.getElementById('frmPersona').addEventListener('submit', manejarSubmit, false);
}

function manejarSubmit(e)
{
    e.preventDefault();
    cargarPersona();
}

function cargarPersona()
{
    //no usa xml

    var xhr = new XMLHttpRequest();
    
    //estado 4 esta ok

    xhr.onreadystatechange = function(){
        document.getElementById('info').innerHTML='<img src="./image/loading.gif">';
        if(this.readyState==4)
        {
            if(this.status==200)
            {
                document.getElementById('info').innerHTML=this.responseText;
            }
            else
            {
                document.getElementById('info').innerHTML='Error:'+this.status+" "+this.statusText;
            }
        }
        
    }

    var frm = document.getElementById('frmPersona');

    var data=new FormData(frm);
    xhr.open('POST', 'pagina1.php', true);
    xhr.setRequestHeader('Content-Type', 'X-Requested-With', 'XHTMLRequest');
    xhr.send(data);
}

function leerDatos()
{
    var cadena='';
    var nombre= document.getElementById('txtNombre').value;
    var edad= document.getElementById('txtEdad').value;
    cadena = "&nombre="+encodeURIComponent(nombre)+"&edad="+edad;

    return cadena;
}

