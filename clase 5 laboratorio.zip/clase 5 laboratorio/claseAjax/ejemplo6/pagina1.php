<?php

$persona="{\"nombre\":\"Juan\",\"edad\":\"32\"}";
echo $persona;

?>