window.addEventListener('load', inicializarEventos);

function inicializarEventos()
{
    document.getElementById('btnCarga').addEventListener('click', cargarPersona);
}

function cargarPersona()
{
    //no usa xml

    var xhr = new XMLHttpRequest();
    
    //estado 4 esta ok

    xhr.onreadystatechange = function(){
        if(this.readyState==4 && this.status==200)
        {
            var unaPersona=JSON.parse(this.responseText);
            document.getElementById('info').innerHTML="Nombre: "+ unaPersona.nombre + " Edad: " + unaPersona.edad;
        }
    }


 //   whr.setRequestHeade
    
    xhr.open('GET', 'pagina1.php', true);
    xhr.send();
}