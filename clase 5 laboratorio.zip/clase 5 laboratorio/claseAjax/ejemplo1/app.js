window.addEventListener('load', inicializarEventos);

function inicializarEventos()
{
    document.getElementById('btnCarga').addEventListener('click', traerTexto);
}

function traerTexto()
{
    //no usa xml

    var xhr = new XMLHttpRequest();

    //estado 4 esta ok

    xhr.onreadystatechange = function(){
        if(this.readyState==4 && this.status==200)
        {
            document.getElementById('info').innerHTML=this.responseText;
        }
    }

    xhr.open('GET', "archivo.txt", true);
    xhr.send();
}