<?php
$nombre_fichero="json/autos.json";
$gestor=fopen($nombre_fichero,"r");
$contenido=fread($gestor, filesize($nombre_fichero));
fclose($gestor);
sleep(3);
echo $contenido;
//levantar el json pasarlo a objetos, en una tabla en el html meter todos los datos
?>