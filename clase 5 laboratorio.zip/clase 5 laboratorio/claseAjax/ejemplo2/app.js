window.addEventListener('load', inicializarEventos);
//LEVANTAR EL JSON, CONVERTIRLO A OBJETOS, MOSTRARLOS EN UNA TABLA
function inicializarEventos()
{
    document.getElementById('btnCarga').addEventListener('click', cargarPersona);
}

function cargarPersona()
{
    //no usa xml

    var xhr = new XMLHttpRequest();
    
    //estado 4 esta ok

    xhr.onreadystatechange = function(){
        if(this.readyState==4 && this.status==200)
        {
            document.getElementById('info').innerHTML=this.responseText;
        }
    }

    var data=leerDatos();
 //   whr.setRequestHeade
    
    xhr.open('GET', 'pagina1.php' + data, true);
    xhr.send();
}

function leerDatos()
{
    var cadena='';
    var nombre= document.getElementById('txtNombre').value;
    var edad= document.getElementById('txtEdad').value;
    cadena = "?nombre="+ nombre +"?edad="+ edad;
    cadena+="&nombre" + encodeURIComponent(nombre) + "&edad=" + encodeURIComponent()
//probar
    return cadena;
}