//variables globales
var lista = [];

var txtNombre;
var txtEdad;

function Persona(nombre, edad)
{
    this.nombre = nombre;
    this.edad = edad;
}


window.addEventListener("load",asignarManejadores,false);

function asignarManejadores()
{
    //asi capturamos el formulario
    var frm = document.getElementById("frmAlta");

    //este permite tomar de forma de array
    //var frm = document.forms[0];
    //the same
    //var frm = document.forms["frmAlta"];


    frm.addEventListener("submit", manejarEnvio, false);

    txtNombre = document.getElementById('txtNombre');
    txtEdad = document.getElementById('txtEdad');

}


function manejarEnvio(e)
{
    //e... para evitar que lo maneje el evento
    e.preventDefault();

    //alert("evento capturado");

    CargarLista();


}

function CargarLista()
{
    //los datos obtenidos son string
    var nuevaPersona = new Persona(txtNombre.value, parseInt( txtEdad.value ) );

    lista.push( nuevaPersona );

    //console.log( lista );

    refrescarLista();

}

function refrescarLista()
{
    var tabla = "<table id='tablaPersonas'> <tr> <th>Nombre</th><th>Edad</th><tr>";

    for(var i= 0 ;i < lista.length;i++)
    {
        tabla += "<tr><td>" + lista[i].nombre + "</td><td>"+ lista[i].edad + "</td></tr>";
    }

    tabla += "</table>";

    document.getElementById("divTabla").innerHTML = tabla;


}