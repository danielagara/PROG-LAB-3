window.addEventListener('load',AsignarManejadores,false);

function AsignarManejadores()
{
    document.getElementById('btnCrearP').addEventListener('click', CrearParrafo);
    document.getElementById('btnCrearImg').addEventListener('click', CrearImgagen);
    document.getElementById('btnClearLast').addEventListener('click', LimpiarUltimo);
    document.getElementById('btnClearFirst').addEventListener('click', LimpiarPrimero);
    document.getElementById('btnSustituir').addEventListener('click', Sustituir);

}

//crear parrafo
//crear un objeto tipo texto
//agregarlo en el textArea
function CrearParrafo()
{
    var parrafo = document.createElement('p');
    //para createTextNode debe tener una etique con un apertura y cierre
    var texto = document.createTextNode( document.getElementById('txtArea').value );

    parrafo.appendChild(texto);

    parrafo.setAttribute('class','claseP')

    document.getElementById('div1').appendChild(parrafo);

}

function CrearImgagen()
{
    var imagen = document.createElement('img');

    imagen.setAttribute('src','./Girdog.png');

    //imagen.height = '300px';
    imagen.alt = 'foto auxiliar';

    document.getElementById('div1').appendChild('imagen');

}


function LimpiarUltimo()
{
    var div = document.getElementById('div1');
    var hijo = div.lastChild;
    div.removeChild(hijo);
}

function LimpiarPrimero()
{
    var div = document.getElementById('div1');
    var hijo = div.firstChild;
    div.removeChild(hijo);
}

function Sustituir()
{
    var parrafo = document.createElement('p');

    var texto = document.createTextNode("hola mundo;");

    parrafo.appendChild(texto);



    //document.getElementById('div1').replaceChild(parrafo, document.getElementById("div1").firstChild );

    document.getElementById('div1').replaceChild(document.getElementById("div1").firstChild ,parrafo);
}






