window.addEventListener('load',AsignarManejadores,false);

function AsignarManejadores()
{
    document.getElementById('btnCambiarTexto').addEventListener('click', CambioTexto);
    document.getElementById('btnCambiarClases').addEventListener('click', CambioClases);
    document.getElementById('btnSacarClases').addEventListener('click', SacarClases);

}

function CambioTexto()
{
    //manejos de id
    document.getElementById('p1').innerHTML = "otro texto p1";
    //como dice elements me devolvera un array, trae todos los parrafos del html
    document.getElementsByTagName('p')[1].innerHTML = "otro texto p2";
    //se referencia a traves de la clase
    document.getElementsByClassName('claseP')[0].innerHTML = "otro tesxto p3";

    var div = document.getElementById('divParrafos');

    div.getElementsByTagName('p')[3].innerHTML = "otro texto p4";


}

function CambioClases()
{
    //primer dato lo que se modifica, el segundo sera por el cual es cambiado
    //document.getElementById('p2').setAttribute('class','claseP');
    //segunda forma, a traves de una propiedad
    document.getElementById('p2').className = 'claseP';

}

function SacarClases()
{
    //document.getElementById('p3').setAttribute('class', "");
    //otra forma y quizas la mas correcta
    document.getElementById('p3').removeAttribute('class');
}



