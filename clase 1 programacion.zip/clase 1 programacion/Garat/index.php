<?php

include "funciones.php";
include "alumno.php";

echo SumaNumeros(1,2);

$nombre = "Daniela";

echo $nombre;

echo "Hola ".$nombre;
echo "<h1> <center> hola mundo </center> </h1>";

var_dump($nombre);

$array = array(1,2,3,"hola");
var_dump($array);
foreach ($array as $element) {
	echo $element;
}

$array2= array("alfa"=>666, "beta"=>555);
$array2["otro"]="esto";
var_dump($array2);
foreach ($array2 as $key => $value) {
	echo $key;
	echo $value;
	# code...
}

$queesto=[];

//$Yesto={};


$obj = new stdclass;

var_dump($queesto);
//var_dump($yesto);
var_dump($obj);

$obj->nombre = "lero";
echo $obj->nombre;

//echo Alumno::Saludar();

$alumno1 = new Alumno();

$alumno1->legajo=1454;
echo $alumno1->Saludar();

//EJERCICIOS GUIA
echo "<br> <br>";
Potencias();

echo "<br> <br>";
echo InviertePalabra("hola");

echo "<br> <br>";
echo EsPalabra("Recuperatorio", 20);

echo "<br> <br>";
echo "LA PAR:  ".EsPar(10);
echo "LA IMPAR:  ".EsImpar(10);