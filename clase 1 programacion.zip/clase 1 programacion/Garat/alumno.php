<?php

class Alumno
{
	public $legajo;

	public function Saludar()
	{
	
		return $this->legajo;
	}

}
