<?php

function SumaNumeros ($numero1, $numero2)
{
	$resultado = $numero1+$numero2;
	return $resultado;
}

//APLICACION 15
function Potencias ()
{
	$numero=4;
	
	while($numero>0)
	{
		for($i=1;$i<5;$i++)
		{
			echo pow($numero,$i)."<br>";

		}

		$numero=$numero-1;
	}
	
}

//APLICACION 16

function InviertePalabra($array)
{
	return strrev($array);
}
//APLICACION 17
function EsPalabra($array, $max)
{
	$retorno = 0;
	if(strlen($array)<$max)
	{
		$retorno=1;
		if(strcmp($array, "Recuperatorio")==0 || strcmp($array, "Parcial") ==0 || strcmp($array, "Programacion")==0)
		{
			$retorno=1;
		}
		else
		{
			$retorno=0;
		}

		return $retorno;
	}
}

//APLICACION 18

function EsPar($numero)
{
	$retorno=true;
	if(($numero % 2)!=0)
	{
		$retorno=false;
	}

	return $retorno;
}

function EsImpar($numero)
{
	return !EsPar($numero);
}
