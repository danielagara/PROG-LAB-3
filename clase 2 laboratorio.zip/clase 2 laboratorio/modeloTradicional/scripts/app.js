//alert("holis");

//var titulo;

window.onload = inicializarEventos;

function inicializarEventos()
{
    //document.getElementById("titulo").onclick=saludar;
    //titulo.onclick=saludar;
    document.getElementById("titulo").addEventListener("click",saludar,false);
    document.getElementById("titulo").addEventListener("click",cambiarColor,false);
    document.getElementById("titulo").addEventListener("click",cambiarTexto,false);
    document.getElementById("titulo").addEventListener("click",function(){
        alert("bye");
    },false);
}

function saludar()
{
    alert("holis");
    document.getElementById("titulo").removeEventListener("click",saludar);
}

function cambiarColor()
{
    titulo.style.color='red';
}

function cambiarTexto()
{
    titulo.innerHTML="sameeeeeeee";
}