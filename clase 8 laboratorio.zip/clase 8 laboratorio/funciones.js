var array=[1, 2, 6, 4, 5, 3];

function cuadrado(array)
{
    for(var i=0;i<array.length;i++)
    {
        array[i]=array[i]*array[i];
        console.log(array[i]);
    }
}

function menores(array)
{
    for(var i=0;i<array.length;i++)
    {
        if(array[i]<4)
        {
            console.log(array[i]);
        }
    }
}

function suma(array)
{
    var acumulador=0;
    for(var i=0;i<array.length;i++)
    {
        acumulador=acumulador+array[i];
    }
    console.log(acumulador);
}