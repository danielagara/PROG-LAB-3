<?php
include_once ".\Materia.php";
include_once ".\manejoArchivos.php";
// nombre, apellido, mail del alumno, materia y código de la materia

class Inscripcion
{
    public $nombreAlumno='';
    public $apellidoAlumno='';
    public $emailAlumno='';
    public $nombreMateria='';
    public $codigoMateria='';

    function __construct($nombreAlumno, $apellidoAlumno, $emailAlumno, $nombreMateria, $codigoMateria)
    {
        $this->nombreAlumno=$nombreAlumno;
        $this->apellidoAlumno=$apellidoAlumno;
        $this->emailAlumno=$emailAlumno;
        $this->nombreMateria=$nombreMateria;
        $this->codigoMateria=$codigoMateria;
    }

    function ToString()
    {
        return $this->nombreAlumno.";".$this->apellidoAlumno.";".$this->emailAlumno.";".$this->nombreMateria.";".$this->codigoMateria.PHP_EOL;
    }

    function row()
    {
        return "<tr>
                    <td>$this->emailAlumno</td>
                    <td>$this->apellidoAlumno</td>
                    <td>$this->nombreAlumno</td>
                    <td>$this->codigoMateria</td>
                    <td>$this->nombreMateria</td>
                </tr>";
    }

    function GetIdentificador()
    {
        return $this->emailAlumno;
    }

}