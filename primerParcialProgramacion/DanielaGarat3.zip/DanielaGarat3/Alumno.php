<?php
//nombre, apellido, email y foto
include_once ".\manejoArchivos.php";

class Alumno
{
    public $nombre='';
    public $apellido='';
    public $email='';
    public $foto='';

    function __construct($nombre, $apellido, $email, $foto)
    {
        $this->nombre=$nombre;
        $this->apellido=$apellido;
        $this->email=$email;
        $this->foto=$foto;
    }

    function ToString()
    {
        return $this->email.";".$this->nombre.";".$this->apellido.";".$this->foto.PHP_EOL;
    }

    function GetIdentificador()
    {
        return $this->email;
    }

    function row()
    {
        return "<tr>
                    <td>$this->apellido</td>
                    <td>$this->nombre</td>
                    <td>$this->email</td>
                    <td><img src='".$this->foto."' alt='Sin foto' height='50' width='50'/></td>
                </tr>";
    }


}