<?php
include_once ".\Alumno.php";
include_once ".\Materia.php";
include_once ".\Inscripciones.php";

function CargarArchivoLista($nombreArchivo, $lista)
{
    if(count($lista)>0)
    {
        LimpiaArchivo($nombreArchivo);
        foreach($lista as $objeto)
        {
            GuardaObjetoArchivo($nombreArchivo,$objeto);
        }
        echo "El archivo ".$nombreArchivo." se actualizó correctamente".PHP_EOL;
    }
        
}

function GuardaObjetoArchivo($nombreArchivo, $objeto)
{
    //echo " llego a guardar obj archivo";
    $fichero=fopen ( $nombreArchivo , "a+");
    fwrite($fichero, $objeto->ToString());
    fclose($fichero);
}


function ArchivoALista($nombreArchivo, $entidad)
{
    //echo "llego a archivo a lista";
    $lista=array();
    $fichero=fopen ( $nombreArchivo , "a+");
    while(!feof($fichero))
    {
        $linea=fgets($fichero);
        $array=explode(";", $linea);
        $objeto="";
        if(count($array)>1)
        {
            switch($entidad)
            {
                case "alumno":
                    $objeto=new Alumno($array[1],$array[2],$array[0],$array[3]);
                    break;
                
                case "materia":
                    $objeto=new Materia($array[1],$array[0],$array[2],$array[3]);
                    break;
    
                case "inscripcion":
                    $objeto=new Inscripcion($array[0],$array[1],$array[2],$array[3],$array[4]);
                    break;
            }
            
            array_push($lista,$objeto);
        }
        
    }

    fclose($fichero);

    return $lista;
}

function LimpiaArchivo($nombreArchivo)
{
    $fichero=fopen ($nombreArchivo , "w+");
    fclose($fichero);
}

