<?php


class Materia
{
    public $nombreMateria='';
    public $codigoMateria='';
    public $cupoAlumnos='';
    public $aula='';

    function __construct($nombreMateria, $codigoMateria, $cupoAlumnos, $aula)
    {
        $this->nombreMateria=$nombreMateria;
        $this->codigoMateria=$codigoMateria;
        $this->cupoAlumnos=$cupoAlumnos;
        $this->aula=$aula;
    }

    function ToString()
    {
        return $this->codigoMateria.";".$this->nombreMateria.";".$this->cupoAlumnos.";".$this->aula.PHP_EOL;
    }

    function GetIdentificador()
    {
        return $this->codigoMateria;
    }
    

}
