<?php
/*include_once ".\Alumno.php";
include_once ".\Materia.php";
include_once ".\Inscripciones.php";*/
include_once ".\Controlador.php";

$controlador=new Controlador();

$archivoAlumno="alumno.txt";
$archivoMateria="materias.txt";
$archivoInscripciones="inscripciones.txt";

$carpetaFotos="Fotos/";
$carpetaFotosBackup="BackUpFotos/";

if(isset($_GET["caso"]))
{
    $caso = $_GET["caso"];
}
else if (isset($_POST["caso"]))
{
    $caso = $_POST["caso"];
}


switch($caso)
{
    case 'cargarAlumno':
       $controlador->cargarAlumno($archivoAlumno, $carpetaFotos); 
    break;

    case 'consultarAlumno':
        $controlador->consultarAlumno($archivoAlumno);
    break;

    case 'cargarMateria':
        $controlador->cargarMateria($archivoMateria);
    break;

    case 'inscribirAlumno':
        $controlador->inscribirAlumno($archivoInscripciones, $archivoMateria);
    break;

    case 'inscripciones':
        $controlador->inscripciones($archivoInscripciones);
    break;

    case 'modificarAlumno':
        $controlador->modificarAlumno($archivoAlumno, $carpetaFotos, $carpetaFotosBackup, $archivoInscripciones);
    break;

    case 'alumnos':
        $controlador->alumnos($archivoAlumno);
    break;

    default:
        echo "Ese caso no esta definido";
    break;
    

}
