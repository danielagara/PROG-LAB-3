<?php

include_once ".\Alumno.php";
include_once ".\Materia.php";
include_once ".\Inscripciones.php";
include_once ".\manejoArchivos.php";
include_once ".\File.php";
include_once ".\Funciones.php";

class Controlador
{
    function cargarAlumno($nombreArchivo,$carpetaFotos)
    {
        if(isset($_POST['nombre'])&&isset($_POST['apellido'])&&isset($_POST['email'])&&isset($_FILES['foto']))
        {
            $nombre=$_POST['nombre'];
            $apellido=$_POST['apellido'];
            $email=$_POST['email'];
            $foto=$_FILES['foto'];

            $file=new File($foto);
            $file->newName = $email.$file->Ext;
            $file->newPath = $carpetaFotos;
            $file->moverFile();


            $alumno = new alumno($email,$apellido,$nombre,$file->newPath.$file->newName);
            $listaAlumnos=ArchivoALista($nombreArchivo,"alumno");
            
            if(BusquedaLista($listaAlumnos,$email)==-1)
            {
                GuardaObjetoArchivo($nombreArchivo, $alumno);
                
                echo "El alumno ".$nombre."; ".$apellido." fue cargado correctamente.";
            }
            else
            {
                echo "El alumno con el mail ".$email." ya se encuentra registrado.";
            }
        }
        else
        {
            echo "Faltan parametros";
        }
    }

    function consultarAlumno($nombreArchivo)
    {
        $match=false;
        if(isset($_GET['apellido']))
        {
            $apellido=$_GET['apellido'];

            $listaAlumnos=array();
            $listaAlumnos=ArchivoALista($nombreArchivo,"alumno");
            foreach ($listaAlumnos as $alumno) 
            {
                if(strcasecmp($alumno->apellido,$apellido)==0)
                {
                    $match=true;
                    echo $alumno->ToString();
                }
            }
    
            if($match==false)
            {
                echo "No existe Alumno con el apellido ".$apellido;
            }
        }
    }
    

    function cargarMateria($nombreArchivo)
    {
        if(isset($_POST['nombreMateria'])&&isset($_POST['codigoMateria'])&&isset($_POST['cupoAlumnos'])&&isset($_POST['aula']))
        {
            $nombreMateria=$_POST['nombreMateria'];
            $codigoMateria=$_POST['codigoMateria'];
            $cupoAlumnos=$_POST['cupoAlumnos'];
            $aula=$_POST['aula'];

            $materia=new Materia($nombreMateria, $codigoMateria, $cupoAlumnos, $aula);
            $listaMaterias=ArchivoALista($nombreArchivo,"materia");

            if(BusquedaLista($listaMaterias,$codigoMateria)==-1)
            {
                GuardaObjetoArchivo($nombreArchivo, $materia);
                
                echo "La materia ".$nombreMateria." fue cargada correctamente.";
            }
            else
            {
                echo "La materia con el código ".$codigoMateria." ya se encuentra registrada.";
            }
            //CargarArchivo("materias.txt", $materia);
        }
        else
        {
            echo "Faltan parametros";
        }
    }

    function inscribirAlumno($nombreArchivoInscripciones, $nombreArchivoMaterias)
    {
        
        if(isset($_GET['nombreAlumno'])&&isset($_GET['apellidoAlumno'])&&isset($_GET['emailAlumno'])&&isset($_GET['nombreMateria'])&&isset($_GET['codigoMateria']))
        {
            $nombreAlumno=$_GET['nombreAlumno'];
            $apellidoAlumno=$_GET['apellidoAlumno'];
            $emailAlumno=$_GET['emailAlumno'];
            $nombreMateria=$_GET['nombreMateria'];
            $codigoMateria=$_GET['codigoMateria'];

            $listaMaterias=ArchivoALista($nombreArchivoMaterias,"materia");
            
            if(BusquedaLista($listaMaterias,$codigoMateria)!=-1)
            {
                if($listaMaterias[BusquedaLista($listaMaterias,$codigoMateria)]->cupoAlumnos>0)
                {
                    $inscripcion=new Inscripcion($nombreAlumno, $apellidoAlumno, $emailAlumno, $nombreMateria,$codigoMateria);
                    $listaMaterias[BusquedaLista($listaMaterias,$codigoMateria)]->cupoAlumnos--;

                    CargarArchivoLista($nombreArchivoMaterias, $listaMaterias);
                    
                    GuardaObjetoArchivo($nombreArchivoInscripciones, $inscripcion);

                    echo "La inscripcion se registró correctamente";
                }
                else
                {
                    echo "No hay cupo para la materia ".$nombreMateria;
                }
            }
            else
            {
                echo "La materia con el codigo ".$codigoMateria." no existe";
            }
        }
        else
        {
            echo "Faltan parametros";
        }
    }

    function inscripciones($nombreArchivo)
    {
        $listaInscripciones= ArchivoALista($nombreArchivo, "inscripcion");
        $listaFiltrada=array();

        foreach($listaInscripciones as $inscripcion)
        {
            
            if(isset($_GET["codigoMateria"]))
            {
                $codigoMateria = $_GET["codigoMateria"];
                if(strcasecmp($inscripcion->codigoMateria,$codigoMateria)==0)//HACE MAL LA COMPARACION
                {
                    array_push($listaFiltrada,$inscripcion);
                }
            }
     
            else
            {
                if (isset($_GET["apellidoAlumno"]))
                {
                    $apellidoAlumno = $_GET["apellidoAlumno"];
                    if(strcasecmp($inscripcion->apellidoAlumno, $apellidoAlumno)==0)
                    {
                        array_push($listaFiltrada,$inscripcion);
                    }
                        
                }
                else
                {
                    array_push($listaFiltrada,$inscripcion);
                }
                    
            }   
        }     

        listToTable("Inscripciones", "
        <tr>
            <th>Email</th>
            <th>Apellido</th>
            <th>Nombre</th>
            <th>Codigo</th>
            <th>Materia</th>
        </tr>", $listaFiltrada);
        
    }

    function modificarAlumno($nombreArchivo, $carpetaFotos, $carpetaFotosBackup, $nombreArchivoInscripciones)
    {
        if(isset($_POST['nombre'])&&isset($_POST['apellido'])&&isset($_POST['email'])&&isset($_FILES['foto']))
        {
            $nombre=$_POST['nombre'];
            $apellido=$_POST['apellido'];
            $email=$_POST['email'];
            $foto=$_FILES['foto'];
            $listaAlumnos=ArchivoALista($nombreArchivo,"alumno");
            
            if(BusquedaLista($listaAlumnos,$email)!=-1)
            {
                $posicion=BusquedaLista($listaAlumnos,$email);

                $directorioFoto = explode(".",$listaAlumnos[$posicion]->foto);
                
                $extension = array_pop($directorioFoto);
                $nombreBackup = $carpetaFotosBackup.$apellido."_".date("YYYYMMDD").".".$extension;

                //echo $nombreBackup;
                if(!file_exists($carpetaFotosBackup))
                {
                    mkdir($carpetaFotosBackup);
                    move_uploaded_file($listaAlumnos[$posicion]->foto,"./".$nombreBackup);
                }
                else
                {
                    //no esta guardando la foto en el backup
                    //rename("./".$listaAlumnos[$posicion]->foto, "./".$nombreBackup);
                    move_uploaded_file($listaAlumnos[$posicion]->foto,"./".$nombreBackup);
                }                
                
                $file = new File($foto);
                $file->newName = $email.$file->Ext;
                $file->newPath = $carpetaFotos;
                $file->moverFile();

                $listaAlumnos[$posicion]->nombre=$nombre;
                $listaAlumnos[$posicion]->apellido=$apellido;
                $listaAlumnos[$posicion]->foto= $file->newPath.$file->newName;
                
                CargarArchivoLista($nombreArchivo, $listaAlumnos);

                $this->actualizarInscripciones($nombreArchivoInscripciones, $email, $nombre, $apellido);
            }
            else
            {
                echo "El alumno con el mail ".$email." no se encuentra registrado en el sistema.";
            }

        }
    }

    function alumnos($nombreArchivo)
    {
        $listaAlumnos= ArchivoALista($nombreArchivo, "alumno");

        listToTable("Alumnos", "
        <tr>
            <th>Apellido</th>
            <th>Nombre</th>
            <th>EMail</th>
            <th>Foto</th>
        </tr>", $listaAlumnos);
    }

    function actualizarInscripciones($nombreArchivo, $emailAlumno, $nombreAlumno, $apellidoAlumno)
    {
        $listaInscripciones=ArchivoALista($nombreArchivo,"inscripcion");

        if(BusquedaLista($listaInscripciones,$emailAlumno)!=-1)
        {
            $posicion=BusquedaLista($listaInscripciones,$emailAlumno);
            $listaInscripciones[$posicion]->nombreAlumno=$nombreAlumno;
            $listaInscripciones[$posicion]->apellidoAlumno=$apellidoAlumno;

            CargarArchivoLista($nombreArchivo, $listaInscripciones);
        }
    }

    
}