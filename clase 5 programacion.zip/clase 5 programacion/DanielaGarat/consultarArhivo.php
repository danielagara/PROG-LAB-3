<?php

include ".\Alumno.php";

function ConsultarAlumno($nombreArchivo)
{
    $match=false;
    if(isset($_GET['apellido']))
    {
        $apellido=$_GET['apellido'];
        $fichero=fopen ( $nombreArchivo , "a+");
        while(!feof($fichero))
        {
            $linea=fgets($fichero);
            $array=explode(";", $linea);
            //falta case insentive

            if(strtolower($array[2])==strtolower($apellido))
            {
                echo $array[0].",".$array[1].",".$array[2].PHP_EOL;
                $match=true;
            }
            
        }

        if($match==false)
        {
            echo "No existe Alumno con el apellido ".$apellido;
        }
    }
}