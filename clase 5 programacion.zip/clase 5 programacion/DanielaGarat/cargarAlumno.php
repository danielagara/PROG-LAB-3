<?php
include ".\Alumno.php";

function CargarAlumno()
{
    if(isset($_POST['nombre'])&&isset($_POST['apellido'])&&isset($_POST['email'])&&isset($_POST['foto']))
    {
        $alumno=new Alumno($_POST['nombre'], $_POST['apellido'], $_POST['email'], $_POST['foto']);
        //echo "llego a cargar";
        return $alumno;
    }
    else
    {
        echo "Faltan parametros";
    }
}

