<?php

function CargarArchivo($nombreArchivo, $objeto)
{
    if(file_exists ($nombreArchivo))
    {
        $fichero=fopen ( $nombreArchivo , "a+");
        fwrite($fichero, $objeto->ToString());
        fclose($fichero);
        echo "El archivo ".$nombreArchivo." se creo correctamente";
    }

}