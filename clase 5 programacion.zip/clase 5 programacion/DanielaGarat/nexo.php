<?php

include ".\cargarAlumno.php";
include ".\manejoArchivos.php";


$caso=$_GET['caso'];

if(isset($_GET['caso']))
{
    switch($caso)
{
    case 'cargarAlumno':
        CargarArchivo("Alumno.txt", CargarAlumno());
    break;

    case 'consultarAlumno':
    break;

    case 'cargarMateria':
    break;

    case 'inscribirAlumno':
    break;

    case 'inscripciones':
    break;

    case 'modificarAlumno':
    break;

    case 'alumnos':
    break;

    default:
    echo "Ese caso no esta definido";
    break;
    

}
}
