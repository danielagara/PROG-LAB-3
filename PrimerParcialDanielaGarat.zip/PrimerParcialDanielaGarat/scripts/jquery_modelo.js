var x = $(document);

x.ready(function () 
{
    $("#ventana_flotante").hide();
});