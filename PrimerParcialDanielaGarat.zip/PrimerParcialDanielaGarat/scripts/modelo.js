//entidades

window.addEventListener("load",asignarManejadores);


function asignarManejadores()
{
    $("#btnAgregar").on({click:CrearFrmAlta});
    //document.getElementById("frmPersona").addEventListener("click",manejarSumit);
}


/*
function heroe(id,nombre,apellido,alias,edad,lado)
{
    this.id= id;
    this.nombre= nombre;
    this.apellido= apellido;
    this.alias= alias;
    this.edad= edad;
    this.lado= lado;
}
*/

//var Superman= new Heroe("Clark","Kent","Superman",34);

//asi capturamos el formulario
//var frm = document.getElementById("frmAlta");
//frm.addEventListener("submit", manejarEnvio, false);
//txtNombre = document.getElementById('txtNombre');
//txtEdad = document.getElementById('txtEdad');
/*
function manejarSumit(e)
{
    e.preventDefault();
    cargarDatos();
}

*/
/*
function cargarDatos()
{
    
    var xhr = new XMLHttpRequest();

    xhr.onreadystatechange = function()
    {
        document.getElementById('info').innerHTML = '<img src="./preloader.gif">';
        if (this.readyState == 4 && this.status == 200) 
        {
            document.getElementById("info").innerHTML = this.responseText;
        }
    }

    var data = {
        "collection":"heroes",
        "heroes":heroe
    }

    var frm = document.getElementById("frmPersona");
    var data = new FormData(frm);
    xhr.open('POST', 'http://localhost:3000/agregar', true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(data);


}*/



