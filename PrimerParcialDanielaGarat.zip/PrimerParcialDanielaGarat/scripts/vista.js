
//CARGA EN LA TABLA LA LISTA DE DATOS
function cargarLista()
{    
    var lista = ListaDatos;
    var tabla = "<table id='tablaHeroes'> <tr> <th>Id</th> <th>Nombre</th> <th>Apellido</th> <th>Alias</th> <th>Edad</th> <th>Lado</th>  </tr>";
    for(var i= 0 ;i < lista.length;i++)
    {
        tabla += "<tr id='"+lista[i].id+"'><td>" + lista[i].id + "</td><td>"+ lista[i].nombre + "</td><td>"+ lista[i].apellido + "</td><td>"+ lista[i].alias + "</td><td>"+ lista[i].edad + "</td><td>"+ lista[i].lado + "</td></tr>";
    }
    tabla += "</table>";
    $("#divTabla").html(tabla);
    for(var i=0; i <$("tr").length; i++)
    {
        $("tr").on({click: forward});
    }
}




//FORMULARIO DE ALTA
function CrearFrmAlta()
{
    if(ListaDatos.length > 0)
    {
        var lista = ListaDatos;
        var frm = "<form action='#' id='frmPersona' class='ventana_flotante'>";
        frm += "<tr> <td>Nombre:</td> <br>";
        frm += "<td> <input type='text' name='nombre' id='txtNombre' autocomplete='off' pattern='[a-zA-Z]{3,10}' required title='solo caracteres y longitud de 3 a 10 caracteres'></td> </tr> <br>";
        frm += "<tr> <td>Apellido:</td> <br>";
        frm += "<td> <input type='text' name='apellido' id='txtApellido' autocomplete='off' pattern='[a-zA-Z]{3,10}' required title='solo caracteres y longitud de 3 a 10 caracteres'></td> </tr> <br>";
        frm += "<tr> <td>Alias:</td> <br>";
        frm += "<td> <input type='text' name='alias' id='txtAlias' autocomplete='off' pattern='[a-zA-Z]{3,10}' required title='solo caracteres y longitud de 3 a 10 caracteres'></td> </tr> <br>";
        frm += "<tr> <td>Edad:</td> <br>";
        frm += "<td> <input type='text' name='edad' id='txtEdad' autocomplete='off' pattern='[0-9]{1,3}' required title='deber estar entre 0 y 999' ></td> </tr> <br>";
        frm += "<tr> <p> Heroe: <input type='radio' name='btnLado' value='heroe' checked/> Villano: <input type='radio' name='btnLado' value='villano' /><br /> </p> </tr>";
        frm += "<td>  <input type='button' value='Alta' id='btnAlta'> <input type='button' value='Cancelar' id='btnCancelar'> </td> </tr>";
        $("#divVF").html(frm);
        $("#btnAlta").on({click:guardar});
        $("#btnCancelar").on({click: esconderForm});
    }
    //else cargando datos espere...
}


//FORMULARIO DE MODIFICAR
//cambiarlo para usar la misma funcion con parametro de que tipo para agregar los botones
function CrearFrmModificar()
{
    var frm = "<form action='#' id='frmPersona' class='ventana_flotante'>";
    frm += "<tr> <td>Nombre:</td> <br>";
    frm += "<td> <input type='text' name='nombre' id='txtNombre' autocomplete='off' pattern='[a-zA-Z]{3,10}' required title='solo caracteres y longitud de 3 a 10 caracteres'></td> </tr> <br>";
    frm += "<tr> <td>Apellido:</td> <br>";
    frm += "<td> <input type='text' name='apellido' id='txtApellido' autocomplete='off' pattern='[a-zA-Z]{3,10}' required title='solo caracteres y longitud de 3 a 10 caracteres'></td> </tr> <br>";
    frm += "<tr> <td>Alias:</td> <br>";
    frm += "<td> <input type='text' name='alias' id='txtAlias' autocomplete='off' pattern='[a-zA-Z]{3,10}' required title='solo caracteres y longitud de 3 a 10 caracteres'></td> </tr> <br>";
    frm += "<tr> <td>Edad:</td> <br>";
    frm += "<td> <input type='text' name='edad' id='txtEdad' autocomplete='off' pattern='[0-9]{1,3}' required title='deber estar entre 0 y 999' ></td> </tr> <br>";
    if(heroeAModificar.lado == "villano")
    {
        frm += "<tr> <p> Heroe: <input id='radioHeroe' type='radio' name='btnLado' value='heroe'/> Villano: <input id='radioVillano' type='radio' name='btnLado' value='villano' checked/><br /> </p> </tr>";
    }
    else
    {
        frm += "<tr> <p> Heroe: <input id='radioHeroe' type='radio' name='btnLado' value='heroe' checked/> Villano: <input id='radioVillano' type='radio' name='btnLado' value='villano' /><br /> </p> </tr>";
    }
    frm += "<td>  <input type='submit' value='Modificar' id='btnModificar'></td> <td>  <input type='submit' value='Borrar'  id='btnBorrar'> <input type='button' value='Cancelar' id='btnCancelar'> </td> </tr>";
    $("#divVF").html(frm);

    $("#btnModificar").on({click:confirmaModificar});
    $("#btnBorrar").on({click:confirmaBaja});
    $("#btnCancelar").on({click:esconderForm});
    //FrmModificar();
    $("#txtNombre").val(heroeAModificar.nombre);
    $("#txtApellido").val(heroeAModificar.apellido);
    $("#txtAlias").val(heroeAModificar.alias);
    $("#txtEdad").val(heroeAModificar.edad);
}
