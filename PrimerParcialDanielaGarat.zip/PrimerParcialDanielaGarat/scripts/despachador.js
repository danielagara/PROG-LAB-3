//LOGICA

//ITEM POR TABLA MODIFICABLE



function buscarIdAlto()
{
    var lista = ListaDatos;
    var retorno = 0;
    if(ListaDatos.length > 0)
    {
        ListaDatos.forEach(element => {
            if(element.id > retorno)
            {
                retorno = element.id;
            }
        });
    }
    if(retorno == 0)
    {
        retorno = 100;
    }
    return retorno;
}

function forward(e)
{
    var objetivo = e.target;
    var objetivoPadre = objetivo.parentElement;
    var idPadre = objetivoPadre.id;
    var Padre = null;
    if(ListaDatos.length > 0)
    {
        ListaDatos.forEach(element => {
            if(element.id == idPadre)
            {
                Padre = element;
            }
        });
    }
    if(Padre != null)
    {
        heroeAModificar = Padre;
        CrearFrmModificar();
    }
}

//GUARDAR ALTA 
function guardar()
{
    var nombre = $("#txtNombre").val();
    var apellido = $("#txtApellido").val();
    var alias = $("#txtAlias").val();
    var edad = $("#txtEdad").val();
    var lado = $("input[name='btnLado']:checked").val();
    var id = buscarIdAlto() + 1;
    heroe = {
        id : id,
        nombre : nombre,
        apellido : apellido,
        alias : alias,
        edad : edad,
        lado : lado
    }
    
    var data = {
        "collection":"heroes",
        "heroe":heroe
    }
    $("#divVF").html(null);
    enviarAlta(data);
    
}


//MODIFICAR

function confirmaModificar(e)
{
    e.preventDefault();
    var respuesta = confirm("¿Desea realizar cambio?");
    if( respuesta == true)
    {
        Modificar();
    }
}


function Modificar()
{
    var nombre = $("#txtNombre").val();
    var apellido = $("#txtApellido").val();
    var alias = $("#txtAlias").val();
    var edad = $("#txtEdad").val();
    var lado = $("input[name='btnLado']:checked").val();
    var id = heroeAModificar.id;
    heroe = {
        id : id,
        nombre : nombre,
        apellido : apellido,
        alias : alias,
        edad : edad,
        lado : lado
    }    
    var data = {
        "collection":"heroes",
        "heroe":heroe
    }
    enviarModificacion(data);
    esconderForm();
}

//BAJA

function confirmaBaja(e)
{
    e.preventDefault();
    var respuesta = confirm("¿Desea eliminarlo?");
    if( respuesta == true)
    {
        Baja();
    }
}

function Baja()
{
    var id = heroeAModificar.id;
    var data = {
        "collection":"heroes",
        "id":id
    }

    enviarEliminaciom(data);
    esconderForm();
}