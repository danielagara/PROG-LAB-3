//COMUNICACIÓN CON SERVER

const server_url = "http://localhost:3000/";
var xhr;
var ListaDatos = new Array();
var heroeAModificar;


//ESCONDER FORMULARIO
function esconderForm()
{
    $("#divVF").html(null);
}

//CARGA DATOS DEL JSON A LA TABLA
window.onload = function()
{
    cargarDatos();  
}

function cargarDatos(){
    var url = 'http://localhost:3000/traer?collection=heroes';

    $('#divTabla').html("<img id='spinner' src='./images/loadergif.gif'>");
    $.get(url,function(data, status)
    {
        if (status == "success")
        {
            
            ListaDatos = data.data;
            console.log(data.message);
            cargarLista();
        }
    }, "json");

}



//GUARDA DATOS ALTA

function enviarAlta(data){
    fetch("http://localhost:3000/agregar",{
        method:"POST",
        headers:{
            "Content-Type" : "application/json"
        },
        body :JSON.stringify(data) 
    }).then( function (response) {
        console.log(response);
        cargarDatos();
    } )
}

//GUARDA DATOS MODIFICAR

function enviarModificacion(data){
    $('#divTabla').html("<img id='spinner' src='./images/loadergif.gif'>");
    fetch("http://localhost:3000/modificar",{
        method:"POST",
        headers:{
            "Content-Type" : "application/json"
        },
        body :JSON.stringify(data) 
    }).then( function (response) {
        console.log(response);
        cargarDatos();
        heroeAModificar = null;
    } )
}

//GUARDA DATOS BAJA

function enviarEliminaciom(data){
    $('#divTabla').html("<img id='spinner' src='./images/loadergif.gif'>");
    fetch("http://localhost:3000/eliminar",{
        method:"POST",
        headers:{
            "Content-Type" : "application/json"
        },
        body :JSON.stringify(data) 
    }).then( function (response) {
        console.log(response);
        cargarDatos();
        heroeAModificar = null;
    } )
}


