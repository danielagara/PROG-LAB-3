//tsc app me actualiza el js que es el archivo que linkeo en el html
console.log("no");
function nombreCompleto(nombre, losDemas) { }
