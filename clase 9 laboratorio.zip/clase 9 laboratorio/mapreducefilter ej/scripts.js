var data = [{"pais":"Argentina","ciudad":"General Belgrano"},
{"pais":"Uruguay","ciudad":"Salto"},
{"pais":"Argentina","ciudad":"General José de San Martín"},
{"pais":"Argentina","ciudad":"Maimará"},
{"pais":"Argentina","ciudad":"Dolavón"},
{"pais":"Argentina","ciudad":"Mar del Plata"},
{"pais":"Chile","ciudad":"Longaví"},
{"pais":"Uruguay","ciudad":"Pan de Azúcar"},
{"pais":"Argentina","ciudad":"Aguilares"},
{"pais":"Chile","ciudad":"Victoria"},
{"pais":"Argentina","ciudad":"General Manuel J. Campos"},
{"pais":"Argentina","ciudad":"El Arañado"},
{"pais":"Argentina","ciudad":"Santiago del Estero"},
{"pais":"Uruguay","ciudad":"Nueva Helvecia"},
{"pais":"Uruguay","ciudad":"Villa del Carmen"},
{"pais":"Argentina","ciudad":"Ingenio La Esperanza"},
{"pais":"Argentina","ciudad":"Villa Nueva"},
{"pais":"Argentina","ciudad":"Huanchillas"},
{"pais":"Argentina","ciudad":"Chicoana"},
{"pais":"Chile","ciudad":"Chiguayante"},
{"pais":"Argentina","ciudad":"Termas de Río Hondo"},
{"pais":"Argentina","ciudad":"Añatuya"},
{"pais":"Chile","ciudad":"Paine"},
{"pais":"Argentina","ciudad":"Villaguay"},
{"pais":"Argentina","ciudad":"Quemú Quemú"},
{"pais":"Argentina","ciudad":"Tío Pujio"},
{"pais":"Argentina","ciudad":"Carhué"},
{"pais":"Argentina","ciudad":"Bella Vista"},
{"pais":"Argentina","ciudad":"General Arenales"},
{"pais":"Argentina","ciudad":"Victoria"},
{"pais":"Argentina","ciudad":"Villa Santa Rita"},
{"pais":"Argentina","ciudad":"Costa Sacate"},
{"pais":"Chile","ciudad":"Salamanca"},
{"pais":"Argentina","ciudad":"Jesús María"},
{"pais":"Uruguay","ciudad":"Florencio Sánchez"},
{"pais":"Argentina","ciudad":"Ingeniero Guillermo N. Juárez"},
{"pais":"Argentina","ciudad":"Carcarañá"},
{"pais":"Argentina","ciudad":"Apóstoles"},
{"pais":"Argentina","ciudad":"San Juan"},
{"pais":"Argentina","ciudad":"Esquina"},
{"pais":"Argentina","ciudad":"Patquía"},
{"pais":"Uruguay","ciudad":"Villa del Carmen"},
{"pais":"Chile","ciudad":"El Tabo"},
{"pais":"Argentina","ciudad":"Isla Verde"},
{"pais":"Argentina","ciudad":"Cipolletti"},
{"pais":"Argentina","ciudad":"Crespo"},
{"pais":"Argentina","ciudad":"Chimbas"},
{"pais":"Uruguay","ciudad":"Pan de Azúcar"},
{"pais":"Argentina","ciudad":"Miramar"},
{"pais":"Argentina","ciudad":"Contraalmirante Cordero"},
{"pais":"Argentina","ciudad":"Coté-Lai"},
{"pais":"Argentina","ciudad":"Bell Ville"},
{"pais":"Argentina","ciudad":"El Carmen"},
{"pais":"Argentina","ciudad":"Miramar"},
{"pais":"Argentina","ciudad":"San Roque"},
{"pais":"Argentina","ciudad":"Chorotis"},
{"pais":"Argentina","ciudad":"Nueve de Julio"},
{"pais":"Uruguay","ciudad":"Pando"},
{"pais":"Uruguay","ciudad":"Salto"},
{"pais":"Argentina","ciudad":"Cerro Corá"},
{"pais":"Argentina","ciudad":"Laguna Paiva"},
{"pais":"Argentina","ciudad":"Leleque"},
{"pais":"Argentina","ciudad":"Posadas"},
{"pais":"Argentina","ciudad":"General Lavalle"},
{"pais":"Chile","ciudad":"San Clemente"},
{"pais":"Chile","ciudad":"Teno"},
{"pais":"Argentina","ciudad":"Villa Santa Rosa"},
{"pais":"Argentina","ciudad":"Villa Ángela"},
{"pais":"Uruguay","ciudad":"Castillos"},
{"pais":"Argentina","ciudad":"Bell Ville"},
{"pais":"Argentina","ciudad":"General Enrique Mosconi"},
{"pais":"Uruguay","ciudad":"Ecilda Paullier"},
{"pais":"Argentina","ciudad":"Villa Nueva"},
{"pais":"Argentina","ciudad":"Avellaneda"},
{"pais":"Argentina","ciudad":"San Fernando del Valle de Catamarca"},
{"pais":"Uruguay","ciudad":"Porvenir"},
{"pais":"Argentina","ciudad":"Resistencia"},
{"pais":"Argentina","ciudad":"Loreto"},
{"pais":"Argentina","ciudad":"Goya"},
{"pais":"Argentina","ciudad":"La Cocha"},
{"pais":"Argentina","ciudad":"Londres"},
{"pais":"Argentina","ciudad":"San Carlos de Bariloche"},
{"pais":"Argentina","ciudad":"Aranguren"},
{"pais":"Argentina","ciudad":"Campo Quijano"},
{"pais":"Argentina","ciudad":"Chacabuco"},
{"pais":"Argentina","ciudad":"Las Parejas"},
{"pais":"Argentina","ciudad":"Tres Arroyos"},
{"pais":"Argentina","ciudad":"Palpalá"},
{"pais":"Argentina","ciudad":"Pehuajó"},
{"pais":"Uruguay","ciudad":"Salto"},
{"pais":"Argentina","ciudad":"Leleque"},
{"pais":"Argentina","ciudad":"Morteros"},
{"pais":"Argentina","ciudad":"Resistencia"},
{"pais":"Argentina","ciudad":"San Francisco"},
{"pais":"Argentina","ciudad":"Bandera"},
{"pais":"Argentina","ciudad":"Gualeguaychú"},
{"pais":"Argentina","ciudad":"Ushuaia"},
{"pais":"Argentina","ciudad":"Quilino"},
{"pais":"Argentina","ciudad":"San Justo"},
{"pais":"Uruguay","ciudad":"Tarariras"}];

var soluciones = {};
/*soluciones.ciudadesArgentinas = function(data){
    return data.filter(function(data, pais){
        return data.Pais === pais;
    })
    .map(function(ciudad){
        return ciudad.nombre;
    });
}*/

soluciones.prueba= data.map(function(valor){
    valor.pais;
})

function VerificarPais(pais, array)
{
    var flag= 0;
    var nuevoArray= [];
    for(var i=0; i<array.length; i++)
    {
        if(array[i]==pais)
        {
            flag++;
        }
    }
}