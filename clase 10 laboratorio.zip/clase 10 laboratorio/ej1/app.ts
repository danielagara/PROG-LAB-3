enum Tipo
{
    Ave,
    Perro,
    Gato,
    Reptil,
    Pez
}

class Animal
{
    tipo:Tipo;
    patas:number;
    edad:number;

    constructor(tipo:Tipo, patas:number, edad:number)
    {
        this.tipo=tipo;
        this.patas=patas;
        this.edad=edad;
    }
}

let unAnimal:Animal = new Animal(Tipo.Perro, 4, 10);

console.log(unAnimal);

function Saludar():void
{
    console.log(`tengo ${this.patas}` );
}
