var Tipo;
(function (Tipo) {
    Tipo[Tipo["Ave"] = 0] = "Ave";
    Tipo[Tipo["Perro"] = 1] = "Perro";
    Tipo[Tipo["Gato"] = 2] = "Gato";
    Tipo[Tipo["Reptil"] = 3] = "Reptil";
    Tipo[Tipo["Pez"] = 4] = "Pez";
})(Tipo || (Tipo = {}));
var Animal = /** @class */ (function () {
    function Animal(tipo, patas, edad) {
        this.tipo = tipo;
        this.patas = patas;
        this.edad = edad;
    }
    return Animal;
}());
var unAnimal = new Animal(Tipo.Perro, 4, 10);
console.log(unAnimal);
function Saludar() {
    console.log("tengo " + this.patas);
}
