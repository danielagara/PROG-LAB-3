<?php

class Mensajes
{
    public $emailRemitente='';
    public $emailDestinatario='';
    public $mensaje='';
    public $foto='';

    function __construct($emailRemitente, $emailDestinatario, $mensaje, $foto)
    {
        $this->emailRemitente=$emailRemitente;
        $this->emailDestinatario=$emailDestinatario;
        $this->mensaje=$mensaje;
        $this->foto=$foto;
    }

    function ToString()
    {
        return $this->emailRemitente.";".$this->emailDestinatario.";".$this->mensaje.";".$this->foto.PHP_EOL;
    }

    function row()
    {
        return "<tr>
                    <td>$this->emailRemitente</td>
                    <td>$this->emailDestinatario</td>
                    <td>$this->mensaje</td>
                    <td><img src='".$this->foto."' alt='Sin foto' height='50' width='50'/></td>
                </tr>";
    }
}