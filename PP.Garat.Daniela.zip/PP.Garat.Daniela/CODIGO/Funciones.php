<?php

function BusquedaLista($lista, $valor)
{
    
    $i=0;
    foreach($lista as $objeto)
    {
        if($objeto->GetIdentificador()==$valor)
        {
            return $i;
        }
        $i++;
    }

    return -1;

}

function listToTable($title,$header,$arrayObj)
{
    $paginaHead = "<!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <meta http-equiv='X-UA-Compatible' content='ie=edge'>
        <style>
            table, th, td {
                border: 1px solid black;
                border-collapse: collapse;
            }
        </style>
        <title>$title</title>
    </head>
    <body>
        <h2 style='color: blue'>$title</h2>
        <table>
            <thead style='color: green'>
            $header
            </thead>
            <tbody> ";

    $paginaFoot ="</tbody>
        </table>
    </body>
    </html>";
    $body = "";

    if(count($arrayObj)>0)
    {
        foreach($arrayObj as $obj)
        {
            $body .= $obj->row();
        }
            
    }
    else
    {
        $rowspan = substr_count($header,"<th>");
        $body .= "<tr><td rowspan=$rowspan>Sin $title</td></tr>";
    }
    
    echo $paginaHead . $body . $paginaFoot;
}