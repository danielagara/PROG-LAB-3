<?php
include_once ".\Usuario.php";
include_once ".\Mensaje.php";

function CargarArchivoLista($nombreArchivo, $lista)
{
    if(count($lista)>0)
    {
        LimpiaArchivo($nombreArchivo);
        foreach($lista as $objeto)
        {
            GuardaObjetoArchivo($nombreArchivo,$objeto);
        }
        //echo "El archivo ".$nombreArchivo." se actualizó correctamente".PHP_EOL;
    }
        
}

function GuardaObjetoArchivo($nombreArchivo, $objeto)
{
    $fichero=fopen ( $nombreArchivo , "a+");
    fwrite($fichero, $objeto->ToString());
    fclose($fichero);
}


function ArchivoALista($nombreArchivo, $entidad)
{
    $lista=array();
    $fichero=fopen ( $nombreArchivo , "a+");
    while(!feof($fichero))
    {
        $linea=fgets($fichero);
        $array=explode(";", $linea);
        $objeto="";
        if(count($array)>1)
        {
            switch($entidad)
            {
                case "usuario":
                    $objeto=new Usuario($array[0],$array[2],$array[1],$array[3]);
                    break;

                case "mensaje":
                    $objeto=new Mensajes($array[0],$array[1],$array[2], $array[3]);
                    break;
            }
            
            array_push($lista,$objeto);
        }
        
    }

    fclose($fichero);

    return $lista;
}

function LimpiaArchivo($nombreArchivo)
{
    $fichero=fopen ($nombreArchivo , "w+");
    fclose($fichero);
}

