<?php
include_once ".\Controlador.php";

$controlador=new Controlador();

$archivoUsuario="usuario.txt";
$archivoMensajes="mensajes.txt";
$carpetaFotos="Fotos/";
$carpetaFotosBackup="BackUpFotos";
$carpetaFotosMensajes="FotosMensajes/";

if(isset($_GET["caso"]))
{
    $caso = $_GET["caso"];
}
else if (isset($_POST["caso"]))
{
    $caso = $_POST["caso"];
}


switch($caso)
{
    case 'cargarUsuario':
       $controlador->cargarUsuario($archivoUsuario, $carpetaFotos); 
    break;

    case 'buscarUsuario':
        $controlador->buscarUsuario($archivoUsuario);
    break;

    case 'listarUsuarios':
        $controlador->listarUsuarios($archivoUsuario);
    break;

    case 'cargarMensaje':
        $controlador->cargarMensaje($archivoMensajes, $carpetaFotosMensajes);
    break;

    case 'mensajesRecibidos':
        $controlador->mensajesRecibidos($archivoMensajes);
    break;

    case 'mensajesEnviados':
        $controlador->mensajesEnviados($archivoMensajes);
    break;

    case 'modificarUsuario':
        $controlador->modificarUsuario($archivoUsuario, $carpetaFotos, $carpetaFotosBackup);
    break;

    case "mensajes":
        $controlador->mensajes($archivoMensajes);
    break;

    default:
        echo "Ese caso no esta definido";
    break;
    

}
