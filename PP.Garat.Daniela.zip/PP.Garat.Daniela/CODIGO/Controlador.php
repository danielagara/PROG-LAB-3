<?php

include_once ".\Usuario.php";
include_once ".\Mensaje.php";
include_once ".\manejoArchivos.php";
include_once ".\File.php";
include_once ".\Funciones.php";

class Controlador
{
    function cargarUsuario($nombreArchivo,$carpetaFotos)
    {
        if(isset($_POST['nombre'])&&isset($_POST['apellido'])&&isset($_POST['email'])&&isset($_FILES['foto']))
        {
            $nombre=$_POST['nombre'];
            $apellido=$_POST['apellido'];
            $email=$_POST['email'];
            $foto=$_FILES['foto'];

            $file=new File($foto);
            $file->newName = $email.$file->Ext;
            $file->newPath = $carpetaFotos;
            $file->moverFile();


            $usuario = new Usuario($email,$apellido,$nombre,$file->newPath.$file->newName);
            $listaUsuarios=ArchivoALista($nombreArchivo,"usuario");
            
            if(BusquedaLista($listaUsuarios,$email)==-1)
            {
                array_push($listaUsuarios, $usuario);
                //GuardaObjetoArchivo($nombreArchivo, $alumno);
                CargarArchivoLista($nombreArchivo, $listaUsuarios);
                echo "El usuario ".$nombre."; ".$apellido." fue cargado correctamente.".PHP_EOL;
            }
            else
            {
                echo "El usuario con el mail ".$email." ya se encuentra registrado.".PHP_EOL;
            }
        }
        else
        {
            echo "Faltan parametros";
        }
    }

    function buscarUsuario($nombreArchivo)
    {
        $match=false;
        if(isset($_GET['apellido']))
        {
            $apellido=$_GET['apellido'];

            $listaUsuarios=array();
            $listaUsuarios=ArchivoALista($nombreArchivo,"usuario");
            foreach ($listaUsuarios as $usuario) 
            {
                if(strcasecmp($usuario->apellido,$apellido)==0)
                {
                    $match=true;
                    echo $usuario->ToString();
                }
            }
    
            if($match==false)
            {
                echo "No existe usuario con apellido ".$apellido;
            }
        }
    }

    function listarUsuarios($nombreArchivo)
    {
        $listaUsuarios=ArchivoALista($nombreArchivo,"usuario");
        foreach ($listaUsuarios as $usuario) 
        {
            echo $usuario->ToString();
        }
    }

    function cargarMensaje($nombreArchivo, $carpetaFotos)
    {
        if(isset($_POST['emailRemitente'])&&isset($_POST['emailDestinatario'])&&isset($_POST['mensaje'])&&isset($_FILES['foto']))
        {
            $emailRemitente=$_POST['emailRemitente'];
            $emailDestinatario=$_POST['emailDestinatario'];
            $mensaje=$_POST['mensaje'];
            $foto=$_FILES['foto'];

            $file=new File($foto);
            $file->newName = $emailRemitente.$mensaje.$file->Ext;
            $file->newPath = $carpetaFotos;
            $file->moverFile();

            $mensajes = new Mensajes($emailRemitente, $emailDestinatario, $mensaje, $file->newPath.$file->newName);
            $listaMensajes=ArchivoALista($nombreArchivo,"mensaje");
            array_push($listaMensajes, $mensajes);
            CargarArchivoLista($nombreArchivo, $listaMensajes);
            echo "El mensaje de ".$emailRemitente." fue enviado a ".$emailDestinatario." correctamente.".PHP_EOL;
        }
        else
        {
            echo "Faltan parametros";
        }
    }

    function mensajesRecibidos($nombreArchivo)
    {
        $match=false;
        if(isset($_GET['emailDestinatario']))
        {
            $emailDestinatario=$_GET['emailDestinatario'];
            //$this->BusquedaMensaje($emailDestinatario, "emailDestinatario");
            $listaMensajes=array();
            $listaMensajes=ArchivoALista($nombreArchivo,"mensaje");
            
            foreach ($listaMensajes as $mensaje) 
            {
                if(strcasecmp($mensaje->emailDestinatario,$emailDestinatario)==0)
                {
                    $match=true;
                    echo "MENSAJE: ".$mensaje->mensaje;
                }
            }
            if($match==false)
            {
                echo $emailDestinatario." no recibió ningún mensaje.".PHP_EOL;
            }


        }
        else
        {
            echo "Faltan parametros";
        }
    }

    function mensajesEnviados($nombreArchivo)
    {
        $match=false;
        if(isset($_GET['emailRemitente']))
        {
            $emailRemitente=$_GET['emailRemitente'];
            $listaMensajes=array();
            $listaMensajes=ArchivoALista($nombreArchivo,"mensaje");
            
            foreach ($listaMensajes as $mensaje) 
            {
                if(strcasecmp($mensaje->emailRemitente,$emailRemitente)==0)
                {
                    $match=true;
                    echo "MENSAJE: ".$mensaje->mensaje;
                }
            }
            if($match==false)
            {
                echo $emailRemitente." no envió ningún mensaje.".PHP_EOL;
            }
        }
        else
        {
            echo "Faltan parametros";
        }
    }

    function modificarUsuario($nombreArchivo, $carpetaFotos, $carpetaFotosBackup)
    {
        if(isset($_POST['nombre'])&&isset($_POST['apellido'])&&isset($_POST['email'])&&isset($_FILES['foto']))
        {
            $nombre=$_POST['nombre'];
            $apellido=$_POST['apellido'];
            $email=$_POST['email'];
            $foto=$_FILES['foto'];
            $listaUsuarios=ArchivoALista($nombreArchivo,"usuario");
            
            if(BusquedaLista($listaUsuarios,$email)!=-1)
            {
                $posicion=BusquedaLista($listaUsuarios,$email);

                //$directorioFoto = explode(".",$listaUsuarios[$posicion]->foto);
                
                //$extension = array_pop($directorioFoto);
                $nombreBackup = "./".$carpetaFotosBackup."/".$apellido."_".date("YYYYMMDD").".jpeg";
                $origen="./".$carpetaFotos.$email.".jpeg";

                if(!file_exists($carpetaFotosBackup))
                {
                    mkdir($carpetaFotosBackup);
                    
                    rename($origen,$nombreBackup);
                }
                else
                {
                    rename($origen, $nombreBackup);
                }                
                
                $file = new File($foto);
                $file->newName = $email.$file->Ext;
                $file->newPath = $carpetaFotos;
                $file->moverFile();

                $listaUsuarios[$posicion]->nombre=$nombre;
                $listaUsuarios[$posicion]->apellido=$apellido;
                $listaUsuarios[$posicion]->foto= $file->newPath.$file->newName;
                
                CargarArchivoLista($nombreArchivo, $listaUsuarios);
                echo "El usuario fue modificado";
                $listaUsuarios[$posicion]->ToString();
            }
            else
            {
                echo "El alumno con el mail ".$email." no se encuentra registrado en el sistema.";
            }

        }
    }

    function mensajes($nombreArchivo)
    {
        $listaMensajes= ArchivoALista($nombreArchivo, "mensaje");

        listToTable("Mensajes", "
        <tr>
            <th>EmailRemitente</th>
            <th>EmailDestinatario</th>
            <th>Mensaje</th>
            <th>Foto</th>
        </tr>", $listaMensajes);
    }
    
}