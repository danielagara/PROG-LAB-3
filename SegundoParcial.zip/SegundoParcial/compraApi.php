<?php 

require_once 'usuario.php';
require_once 'compra.php';
require_once 'IApiCompras.php';
require_once 'AutentificadorJWT.php';

class compraApi extends compra implements IApiCompras
{
    function __construct()
    {
    }

    public function RegistrarCompra($request, $response, $args)
    {
        $body=$request->getParsedBody();
        $arrayConToken = $request->getHeader('token');
        $token=$arrayConToken[0];
        
        $nombreUsuario=AutentificadorJWT::ObtenerData($token);//como lo toma del token, ya se que esta registrado

        $unaCompra = new compra($body["nombreArticulo"], $body["fechaCompra"], $body["precio"], $nombreUsuario);
        $insertOk=compra::InsertarCompra($unaCompra);

        $archivos = $request->getUploadedFiles();
        $foto= $archivos['imagen'];
        if($insertOk>0)
        {
            $nuevaCarpeta="IMGCompras";//PARA LOS NOMBRES, VER EL TEMA DE MISMO MISMO NOMBRE, traer id con insert
            if(!file_exists($nuevaCarpeta))
            {
                mkdir($nuevaCarpeta);
            }
            $nuevoNombre="./$nuevaCarpeta/".$insertOk.$unaCompra->nombreArticulo.".jpg";
            $foto->moveTo($nuevoNombre);

            $response="La compra se registro correctamente";
        }
        else if($insertOk==0)
        {
            $response="Ocurrió un error al registrar su compra";
        }

        return $response;
    }

    public function ArmaListaCompras($request, $response, $args)
    {
        $objDelaRespuesta= new stdclass();
        $objDelaRespuesta->respuesta="";

        $listadoCompras=compra::TraerTodasLasCompras();//revisar como lo devuelve
        //$objDelaRespuesta->respuesta=$compras;
        //$nueva=$response->withJson($objDelaRespuesta, 401);
        $respuesta="";
        $carpetaFotos="IMGCompras";
        $rows="";
        
        
        foreach($listadoCompras as $compra)
        {
            $imagenCompra = "./$carpetaFotos/" . $compra['id'] . $compra['nombreArticulo'] . ".jpg";
            if(file_exists($imagenCompra))
            {
                $foto = "<img src='\\IMGCompras\\{$compra['id']}{$compra['nombreArticulo']}.jpg' alt='Foto compra ID {$compra['id']}'height='100' width='100'>";
                $rows .= "<tr><td>" . $compra['id'] . "</td>";
                $rows .= "<td>" . $compra['nombreArticulo'] . "</td>";
                $rows .= "<td>" . $compra['precio'] . "</td>";
                //$rows .= "<td>" . $compra['fechaCompra'] . "</td>";
                $rows .= "<td>" . $compra['usuario'] . "</td>";
                $rows .= "<td>" . $foto . "</td></tr>";
            }
            else
            {
                $rows .= "<tr><td>" . $compra['id'] . "</td>";
                $rows .= "<td>" . $compra['nombreArticulo'] . "</td>";
                $rows .= "<td>" . $compra['precio'] . "</td>";
                //$rows .= "<td>" . $compra['fechaCompra'] . "</td>";
                $rows .= "<td>" . $compra['usuario'] . "</td>";
                $rows .= "<td>" . "No tiene foto" . "</td></tr>";
            }
        }


               /* $rows .= "<tr><td>" . "5" . "</td>";
                $rows .= "<td>" . "zpatilla" . "</td>";
                $rows .= "<td>" . "0.5" . "</td>";
                //$rows .= "<td>" . $compra['fechaCompra'] . "</td>";
                $rows .= "<td>" . "daniela" . "</td>";
                $rows .= "<td>" . "No tiene foto" . "</td></tr>"*/
        $output = "<table id='tablaCompras'><tr><th>Id Compra</th><th>Articulo</th><th>Precio</th><th>Usuario</th><th>Foto</th></tr>" . $rows . "</table>";

        
        $objDelaRespuesta->respuesta=$output;
        $nueva=$response->withJson($objDelaRespuesta, 401);
        return $response;
    }
    
}