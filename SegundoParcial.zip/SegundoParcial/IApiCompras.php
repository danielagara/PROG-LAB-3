<?php 

interface IApiCompras{
    public function RegistrarCompra($request, $response, $args);
}
?>